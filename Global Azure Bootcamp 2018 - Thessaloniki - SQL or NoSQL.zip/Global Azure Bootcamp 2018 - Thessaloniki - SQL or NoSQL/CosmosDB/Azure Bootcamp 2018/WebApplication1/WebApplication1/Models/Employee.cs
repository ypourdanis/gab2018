﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace WebAppCosmosDB.Models
{
    public class Employee
    {
        [JsonProperty(PropertyName = "BusinessEntityID")]
        public string BusinessEntityID { get; set; }

        [JsonProperty(PropertyName = "Title")]
        public string Title { get; set; }

        [JsonProperty(PropertyName = "FirstName")]
        public string FirstName { get; set; }

        [JsonProperty(PropertyName = "MiddleName")]
        public string MiddleName { get; set; }

        [JsonProperty(PropertyName = "LastName")]
        public string LastName { get; set; }
    }
}